<?php
    $host = "localhost";
    $login = "root";
    $password = "root";
    $dbname = "netflix";
?>